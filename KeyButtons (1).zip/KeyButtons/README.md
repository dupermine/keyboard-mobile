# Key Buttons

Плавающие кнопки поверх экрана, которые эмулируют нажатия клавиш физической клавиатуры.

## Сборка
1. Установи Android Studio (Koala или новее).
2. File → Open → папка KeyButtons, дождись Gradle Sync.
3. Build → Build APK(s) → app/build/outputs/apk/debug/app-debug.apk

## Использование
1. Установи Shizuku (Play Market / GitHub) и запусти его (Wireless debugging или root).
2. В приложении: дай разрешение «поверх других окон» и разрешение Shizuku.
3. Добавь кнопку: подпись + комбинация (CTRL+C, F5, SPACE, ENTER, ESCAPE, DPAD_UP, A, ...).
4. Нажми «Показать кнопки». Кнопки можно перетаскивать, нажатие = отправка клавиши.

Имена клавиш — это константы KeyEvent без префикса KEYCODE_ (например KEYCODE_PAGE_UP → PAGE_UP).
Модификаторы: CTRL, SHIFT, ALT, META.

## Без Shizuku
Работают только BACK, HOME, RECENTS, NOTIFICATIONS (через службу доступности).
Остальные клавиши Android разрешает вводить только системе/shell — поэтому нужен Shizuku.

## Логи
- Кнопка «Логи» в главном экране: просмотр, копирование, отправка, очистка (файл `log.txt`, до ~200 КБ).
- Те же сообщения идут в Logcat с тегом `KeyButtons`:  `adb logcat -s KeyButtons`
- Логируются: старт приложения, состояние Shizuku (binder/разрешение), каждое нажатие кнопки,
  каждое отправленное событие клавиши (DOWN/UP, код, meta, результат), ошибки и падения (crash).
