package com.example.keybuttons

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Btn(val label: String, val combo: String, var x: Int, var y: Int)

object Store {
    @Volatile var overlayRunning = false

    private fun p(c: Context) = c.getSharedPreferences("store", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Btn> {
        val out = mutableListOf<Btn>()
        try {
            val a = JSONArray(p(c).getString("buttons", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out += Btn(o.getString("l"), o.getString("c"), o.getInt("x"), o.getInt("y"))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<Btn>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("l", it.label).put("c", it.combo).put("x", it.x).put("y", it.y))
        }
        p(c).edit().putString("buttons", a.toString()).apply()
    }

    fun useShizuku(c: Context) = p(c).getBoolean("shizuku", true)
    fun setUseShizuku(c: Context, v: Boolean) = p(c).edit().putBoolean("shizuku", v).apply()
}
