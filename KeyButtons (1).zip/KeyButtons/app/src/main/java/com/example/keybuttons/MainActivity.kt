package com.example.keybuttons

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var etLabel: EditText
    private lateinit var etCombo: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        status = TextView(this).apply { textSize = 14f }
        col.addView(status)

        col.addView(button("1. Разрешить показ поверх других окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("2. Дать разрешение Shizuku") {
            try {
                if (!Shizuku.pingBinder()) { Logger.w("requestPermission: Shizuku не запущен"); toast("Shizuku не запущен. Открой Shizuku и запусти службу.") }
                else { Logger.i("requestPermission: запрашиваю"); Shizuku.requestPermission(1) }
            } catch (t: Throwable) { Logger.e("requestPermission: ошибка", t); toast("Shizuku не установлен") }
        })
        col.addView(button("(Без Shizuku) Служба доступности: BACK/HOME/RECENTS") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(Switch(this).apply {
            text = "Использовать Shizuku"
            isChecked = Store.useShizuku(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Store.setUseShizuku(this@MainActivity, v) }
        })

        col.addView(TextView(this).apply {
            text = "\nНовая кнопка"; textSize = 18f
        })
        etLabel = EditText(this).apply { hint = "Подпись (например: Ctrl+C)" }
        etCombo = EditText(this).apply { hint = "Комбинация: CTRL+C, F5, SPACE, ENTER, DPAD_UP, BACK" }
        col.addView(etLabel); col.addView(etCombo)
        col.addView(button("Добавить кнопку") { addBtn() })

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        col.addView(button("▶ Показать кнопки на экране") {
            if (!Settings.canDrawOverlays(this)) { Logger.w("overlay: нет разрешения"); toast("Сначала дай разрешение (шаг 1)"); return@button }
            Logger.i("UI: показать кнопки")
            startForegroundService(Intent(this, OverlayService::class.java))
        })
        col.addView(button("■ Скрыть кнопки") {
            Logger.i("UI: скрыть кнопки")
            startService(Intent(this, OverlayService::class.java).setAction("STOP"))
        })
        col.addView(button("\uD83D\uDCCB Логи") { startActivity(Intent(this, LogActivity::class.java)) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun addBtn() {
        val l = etLabel.text.toString().trim()
        val c = etCombo.text.toString().trim()
        if (l.isEmpty() || c.isEmpty()) { toast("Заполни оба поля"); return }
        val list = Store.load(this)
        list += Btn(l, c, 100, 300 + list.size * 200)
        Logger.i("UI: добавлена кнопка '$l' -> '$c'")
        Store.save(this, list)
        etLabel.text.clear(); etCombo.text.clear()
        refresh(); reloadOverlay()
    }

    private fun reloadOverlay() {
        if (Store.overlayRunning) startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val shizuku = KeyInjector.shizukuReady()
        Logger.d("refresh: overlay=$overlay shizuku=$shizuku a11y=${KeyAccessibilityService.instance != null}")
        status.text = "Оверлей: ${if (overlay) "OK" else "нет разрешения"}\n" +
            "Shizuku: ${if (shizuku) "готов" else "не готов"}\n" +
            "Служба доступности: ${if (KeyAccessibilityService.instance != null) "включена" else "выключена"}"

        listBox.removeAllViews()
        Store.load(this).forEachIndexed { i, b ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply {
                text = "${b.label}  →  ${b.combo}"
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(Button(this).apply {
                text = "Тест"
                setOnClickListener {
                    Logger.i("UI: тест кнопки '${b.label}'")
                    KeyInjector.send(this@MainActivity, b.combo, Store.useShizuku(this@MainActivity))
                        ?.let { toast(it) } ?: toast("Отправлено")
                }
            })
            row.addView(Button(this).apply {
                text = "✕"
                setOnClickListener {
                    val l = Store.load(this@MainActivity); Logger.i("UI: удалена кнопка '${l[i].label}'"); l.removeAt(i)
                    Store.save(this@MainActivity, l); refresh(); reloadOverlay()
                }
            })
            listBox.addView(row)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
