package com.example.keybuttons

import android.content.Context
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/** Combo format: "A", "SPACE", "F5", "CTRL+C", "CTRL+SHIFT+ESCAPE", "DPAD_UP" ... */
object KeyInjector {

    private val MODS = mapOf(
        "CTRL" to (KeyEvent.KEYCODE_CTRL_LEFT to KeyEvent.META_CTRL_ON),
        "SHIFT" to (KeyEvent.KEYCODE_SHIFT_LEFT to KeyEvent.META_SHIFT_ON),
        "ALT" to (KeyEvent.KEYCODE_ALT_LEFT to KeyEvent.META_ALT_ON),
        "META" to (KeyEvent.KEYCODE_META_LEFT to KeyEvent.META_META_ON),
    )

    private val GLOBAL = mapOf(
        "BACK" to android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK,
        "HOME" to android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME,
        "RECENTS" to android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS,
        "NOTIFICATIONS" to android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS,
    )

    private var inputManager: Any? = null

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        Logger.w("shizukuReady check failed", t); false
    }

    /** returns null on success or an error message */
    fun send(ctx: Context, combo: String, preferShizuku: Boolean): String? {
        val parts = combo.trim().uppercase().split("+").map { it.trim() }.filter { it.isNotEmpty() }
        Logger.i("send: combo='$combo' parts=$parts preferShizuku=$preferShizuku shizukuReady=${shizukuReady()}")
        if (parts.isEmpty()) { Logger.w("send: пустая комбинация"); return "Пустая комбинация" }

        if (preferShizuku && shizukuReady()) {
            return try {
                injectCombo(parts)
                Logger.i("send: OK через Shizuku")
                null
            } catch (t: Throwable) {
                val root = t.cause ?: t
                Logger.e("send: ошибка Shizuku-инъекции", root)
                inputManager = null // пересоздадим binder при следующей попытке
                "Ошибка Shizuku: ${root.message}"
            }
        }

        if (parts.size == 1 && GLOBAL.containsKey(parts[0])) {
            val svc = KeyAccessibilityService.instance
            if (svc == null) { Logger.w("send: служба доступности выключена"); return "Включи службу доступности в приложении" }
            val ok = svc.performGlobalAction(GLOBAL.getValue(parts[0]))
            Logger.i("send: global action ${parts[0]} -> $ok")
            return if (ok) null else "Не удалось выполнить действие"
        }

        val msg = if (preferShizuku) "Shizuku не запущен или нет разрешения"
        else "Без Shizuku доступны только BACK, HOME, RECENTS, NOTIFICATIONS"
        Logger.w("send: отказ — $msg")
        return msg
    }

    private fun injectCombo(parts: List<String>) {
        val keyName = parts.last()
        val code = KeyEvent.keyCodeFromString("KEYCODE_$keyName")
        if (code == KeyEvent.KEYCODE_UNKNOWN) throw IllegalArgumentException("Неизвестная клавиша: $keyName")

        var meta = 0
        val modCodes = mutableListOf<Int>()
        for (m in parts.dropLast(1)) {
            val (c, flag) = MODS[m] ?: throw IllegalArgumentException("Неизвестный модификатор: $m")
            modCodes += c; meta = meta or flag
        }

        var cur = 0
        for (c in modCodes) {
            cur = cur or MODS.values.first { it.first == c }.second
            inject(key(KeyEvent.ACTION_DOWN, c, cur))
        }
        inject(key(KeyEvent.ACTION_DOWN, code, meta))
        inject(key(KeyEvent.ACTION_UP, code, meta))
        for (c in modCodes.reversed()) {
            cur = cur and MODS.values.first { it.first == c }.second.inv()
            inject(key(KeyEvent.ACTION_UP, c, cur))
        }
    }

    private fun key(action: Int, code: Int, meta: Int): KeyEvent {
        val now = SystemClock.uptimeMillis()
        return KeyEvent(
            now, now, action, code, 0, meta,
            KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD
        )
    }

    private fun inject(ev: InputEvent) {
        val im = inputManager ?: run {
            Logger.d("inject: получаю IInputManager через Shizuku binder")
            val binder: IBinder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            Class.forName("android.hardware.input.IInputManager\$Stub")
                .getMethod("asInterface", IBinder::class.java)
                .invoke(null, binder)!!
                .also { inputManager = it }
        }
        val m = im.javaClass.getMethod(
            "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
        )
        val k = ev as KeyEvent
        val res = m.invoke(im, ev, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        val act = if (k.action == KeyEvent.ACTION_DOWN) "DOWN" else "UP"
        Logger.d("inject: $act ${KeyEvent.keyCodeToString(k.keyCode)} meta=${k.metaState} -> $res")
        if (res == false) Logger.w("inject: система отклонила событие (вернула false)")
    }
}
