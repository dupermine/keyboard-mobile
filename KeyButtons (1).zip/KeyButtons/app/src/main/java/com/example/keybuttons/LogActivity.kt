package com.example.keybuttons

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.*

class LogActivity : Activity() {
    private lateinit var tv: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 32, 16, 16) }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { f() }
        }
        row.addView(btn("Обновить") { load() })
        row.addView(btn("Копировать") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", Logger.read()))
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
        })
        row.addView(btn("Поделиться") {
            val text = Logger.read().takeLast(100_000)
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Логи"))
        })
        row.addView(btn("Очистить") { Logger.clear(); load() })
        root.addView(row)

        tv = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 10f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(tv) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        tv.text = Logger.read().ifEmpty { "(лог пуст)" }
        scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }
}
