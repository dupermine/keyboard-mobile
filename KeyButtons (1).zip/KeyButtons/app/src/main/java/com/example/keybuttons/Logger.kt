package com.example.keybuttons

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Пишет и в Logcat (тег KeyButtons), и в файл filesDir/log.txt (виден в экране «Логи»). */
object Logger {
    private const val TAG = "KeyButtons"
    private const val MAX_BYTES = 200_000L
    private var file: File? = null
    private val fmt = SimpleDateFormat("dd.MM HH:mm:ss.SSS", Locale.US)

    fun init(c: Context) { file = File(c.applicationContext.filesDir, "log.txt") }

    fun d(msg: String) = write('D', msg, null)
    fun i(msg: String) = write('I', msg, null)
    fun w(msg: String, t: Throwable? = null) = write('W', msg, t)
    fun e(msg: String, t: Throwable? = null) = write('E', msg, t)

    @Synchronized
    private fun write(level: Char, msg: String, t: Throwable?) {
        when (level) {
            'D' -> Log.d(TAG, msg, t)
            'I' -> Log.i(TAG, msg, t)
            'W' -> Log.w(TAG, msg, t)
            else -> Log.e(TAG, msg, t)
        }
        val f = file ?: return
        try {
            val sb = StringBuilder()
            sb.append(fmt.format(Date())).append(' ').append(level).append(' ').append(msg).append('\n')
            if (t != null) sb.append(Log.getStackTraceString(t)).append('\n')
            if (f.exists() && f.length() > MAX_BYTES) {
                // оставляем последнюю половину
                val tail = f.readText().takeLast((MAX_BYTES / 2).toInt())
                f.writeText(tail)
            }
            f.appendText(sb.toString())
        } catch (_: Exception) {}
    }

    @Synchronized fun read(): String = try { file?.takeIf { it.exists() }?.readText() ?: "" } catch (_: Exception) { "" }
    @Synchronized fun clear() { try { file?.writeText("") } catch (_: Exception) {} }
}
