package com.example.keybuttons

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class KeyAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: KeyAccessibilityService? = null }

    override fun onServiceConnected() { instance = this; Logger.i("AccessibilityService: подключена") }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; Logger.i("AccessibilityService: отключена"); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
