package com.example.keybuttons

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableListOf<View>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { Logger.i("OverlayService: STOP"); stopSelf(); return START_NOT_STICKY }
        Logger.i("OverlayService: start/reload")
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rebuild()
        Store.overlayRunning = true
        return START_STICKY
    }

    override fun onDestroy() {
        Logger.i("OverlayService: destroy"); clear(); Store.overlayRunning = false; super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Key Buttons работает")
            .setContentText("Нажми, чтобы остановить")
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, 0x40000000) // SPECIAL_USE
        else startForeground(1, n)
    }

    private fun clear() {
        views.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        views.clear()
    }

    private fun rebuild() {
        clear()
        val list = Store.load(this)
        Logger.i("OverlayService: кнопок на экране = ${list.size}")
        list.forEach {
            try { addButton(it, list) } catch (t: Throwable) { Logger.e("addButton '${it.label}' failed", t) }
        }
    }

    private fun addButton(b: Btn, all: List<Btn>) {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = b.label
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            alpha = 0.85f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1565C0"))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = b.x; y = b.y }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        b.x = lp.x; b.y = lp.y; Store.save(this, all)
                        Logger.d("кнопка '${b.label}' перемещена в (${b.x}, ${b.y})")
                    } else {
                        Logger.i("нажата кнопка '${b.label}' (${b.combo})")
                        KeyInjector.send(this, b.combo, Store.useShizuku(this))?.let {
                            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            true
        }
        wm.addView(tv, lp)
        views += tv
    }
}
