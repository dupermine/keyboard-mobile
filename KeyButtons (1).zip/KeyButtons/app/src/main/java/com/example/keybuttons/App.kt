package com.example.keybuttons

import android.app.Application
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Logger.init(this)
        Logger.i("=== App start, SDK=${android.os.Build.VERSION.SDK_INT}, ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} ===")

        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Logger.e("CRASH в потоке ${t.name}", e)
            prev?.uncaughtException(t, e)
        }

        try {
            HiddenApiBypass.addHiddenApiExemptions("L")
            Logger.i("HiddenApiBypass: OK")
        } catch (t: Throwable) { Logger.e("HiddenApiBypass: ошибка", t) }

        try {
            Shizuku.addBinderReceivedListener { Logger.i("Shizuku: binder получен") }
            Shizuku.addBinderDeadListener { Logger.w("Shizuku: binder умер") }
            Shizuku.addRequestPermissionResultListener { _, result ->
                Logger.i("Shizuku: результат запроса разрешения = $result (0 = выдано)")
            }
        } catch (t: Throwable) { Logger.e("Shizuku listeners: ошибка", t) }
    }
}
